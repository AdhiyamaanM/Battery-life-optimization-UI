// // // import React, { useState } from "react";
// // // import {
// // //   Paper,
// // //   Table,
// // //   TableBody,
// // //   TableCell,
// // //   TableContainer,
// // //   TableHead,
// // //   TableRow,
// // //   TablePagination,
// // //   IconButton,
// // //   Box,
// // // } from "@mui/material";
// // // import ExpandMoreIcon from "@mui/icons-material/ExpandMore";
// // // import ExpandLessIcon from "@mui/icons-material/ExpandLess";

// // // // Full Column Headers List
// // // const columns = [
// // //   "elv_spy",
// // //   "speed",
// // //   "soc",
// // //   "amb_temp",
// // //   "regenwh",
// // //   "Motor Pwr(w)",
// // //   "Aux Pwr(100w)",
// // //   "Motor Temp",
// // //   "Torque Nm",
// // //   "rpm",
// // //   "capacity",
// // //   "ref_consumption",
// // //   "wind_mph",
// // //   "wind_kph",
// // //   "wind_degree",
// // //   "Frontal_Wind",
// // //   "Veh_deg",
// // //   "totalVehicles",
// // //   "speedAvg",
// // //   "max_speed",
// // //   "radius",
// // //   "step",
// // //   "acceleration(m/s²)",
// // //   "actualBatteryCapacity(Wh)",
// // //   "speed(m/s)",
// // //   "speedFactor",
// // //   "totalEnergyConsumed(Wh)",
// // //   "totalEnergyRegenerated(Wh)",
// // //   "lon",
// // //   "lat",
// // //   "alt",
// // //   "slope(º)",
// // //   "completedDistance(km)",
// // //   "mWh",
// // //   "remainingRange(km)",
// // // ];

// // // // Generate Sample Data
// // // const generateSampleData = (numRows = 100) =>
// // //   Array.from({ length: numRows }, (_, index) =>
// // //     columns.reduce((acc, column) => {
// // //       acc[column] = `${column}-${index + 1}`; // Placeholder Data
// // //       return acc;
// // //     }, {})
// // //   );

// // // const DataExplorer = () => {
// // //   const [data] = useState(generateSampleData(100)); // 100 Sample Rows
// // //   const [page, setPage] = useState(0);
// // //   const rowsPerPage = 10;
// // //   const [expanded, setExpanded] = useState(false); // Expand state

// // //   const handleChangePage = (_event, newPage) => {
// // //     setPage(newPage);
// // //   };

// // //   return (
// // //     <Box
// // //       sx={{ display: "flex", flexDirection: "column", alignItems: "center" }}
// // //     >
// // //       {/* Expand/Collapse Button */}
// // //       <IconButton onClick={() => setExpanded(!expanded)} sx={{ mb: 1 }}>
// // //         {expanded ? (
// // //           <ExpandLessIcon fontSize="large" />
// // //         ) : (
// // //           <ExpandMoreIcon fontSize="large" />
// // //         )}
// // //       </IconButton>

// // //       {/* Table */}
// // //       <Paper
// // //         sx={{
// // //           width: expanded ? "90vw" : "600px", // Expands when clicked
// // //           height: expanded ? "80vh" : "auto",
// // //           overflow: "hidden",
// // //           padding: 2,
// // //           transition: "all 0.3s ease-in-out",
// // //         }}
// // //       >
// // //         <TableContainer
// // //           sx={{ maxHeight: expanded ? "70vh" : "auto", overflowX: "auto" }}
// // //         >
// // //           <Table stickyHeader>
// // //             <TableHead>
// // //               <TableRow>
// // //                 {columns.map((column) => (
// // //                   <TableCell
// // //                     key={column}
// // //                     sx={{
// // //                       fontWeight: "bold",
// // //                       background: "#2a5353",
// // //                       color: "white",
// // //                       minWidth: 150,
// // //                     }}
// // //                   >
// // //                     {column}
// // //                   </TableCell>
// // //                 ))}
// // //               </TableRow>
// // //             </TableHead>
// // //             <TableBody>
// // //               {data
// // //                 .slice(page * rowsPerPage, (page + 1) * rowsPerPage)
// // //                 .map((row, index) => (
// // //                   <TableRow key={index}>
// // //                     {columns.map((column) => (
// // //                       <TableCell key={column}>{row[column]}</TableCell>
// // //                     ))}
// // //                   </TableRow>
// // //                 ))}
// // //             </TableBody>
// // //           </Table>
// // //         </TableContainer>

// // //         {/* Pagination (Hidden in expanded mode) */}
// // //         {!expanded && (
// // //           <TablePagination
// // //             component="div"
// // //             rowsPerPageOptions={[10]} // Fixed to 10 rows per page
// // //             count={data.length}
// // //             rowsPerPage={rowsPerPage}
// // //             page={page}
// // //             onPageChange={handleChangePage}
// // //           />
// // //         )}
// // //       </Paper>
// // //     </Box>
// // //   );
// // // };

// // // export default DataExplorer;

// // import React, { useState } from "react";
// // import * as XLSX from "xlsx";
// // import {
// //   Paper,
// //   Table,
// //   TableBody,
// //   TableCell,
// //   TableContainer,
// //   TableHead,
// //   TableRow,
// //   TablePagination,
// //   IconButton,
// //   Box,
// //   Button,
// //   Typography,
// // } from "@mui/material";
// // import ExpandMoreIcon from "@mui/icons-material/ExpandMore";
// // import ExpandLessIcon from "@mui/icons-material/ExpandLess";

// // const DataExplorer = () => {
// //   const [data, setData] = useState([]); // Table data
// //   const [columns, setColumns] = useState([]); // Column headers
// //   const [page, setPage] = useState(0);
// //   const rowsPerPage = 10;
// //   const [expanded, setExpanded] = useState(false);

// //   // Handle file upload
// //   const handleFileUpload = (event) => {
// //     const file = event.target.files[0];
// //     if (!file) return;

// //     const reader = new FileReader();
// //     reader.onload = (e) => {
// //       const binaryStr = e.target.result;
// //       const workbook = XLSX.read(binaryStr, { type: "binary" });
// //       const sheetName = workbook.SheetNames[0];
// //       const sheet = workbook.Sheets[sheetName];

// //       // Convert sheet to JSON
// //       const parsedData = XLSX.utils.sheet_to_json(sheet, { header: 1 });

// //       if (parsedData.length > 0) {
// //         setColumns(parsedData[0]); // First row as headers
// //         setData(parsedData.slice(1)); // Remaining rows as data
// //       }
// //     };
// //     reader.readAsBinaryString(file);
// //   };

// //   return (
// //     <Box
// //       sx={{
// //         display: "flex",
// //         flexDirection: "column",
// //         alignItems: "center",
// //         gap: 2,
// //       }}
// //     >
// //       {/* File Upload Button */}
// //       <Button variant="contained" component="label">
// //         Upload CSV / Excel
// //         <input
// //           type="file"
// //           hidden
// //           accept=".csv, .xlsx, .xls"
// //           onChange={handleFileUpload}
// //         />
// //       </Button>

// //       {/* Expand/Collapse Button */}
// //       <IconButton onClick={() => setExpanded(!expanded)}>
// //         {expanded ? (
// //           <ExpandLessIcon fontSize="large" />
// //         ) : (
// //           <ExpandMoreIcon fontSize="large" />
// //         )}
// //       </IconButton>

// //       {/* Table */}
// //       <Paper
// //         sx={{
// //           width: expanded ? "90vw" : "600px",
// //           height: expanded ? "80vh" : "auto",
// //           overflow: "hidden",
// //           padding: 2,
// //           transition: "all 0.3s ease-in-out",
// //         }}
// //       >
// //         {data.length > 0 ? (
// //           <TableContainer
// //             sx={{ maxHeight: expanded ? "70vh" : "auto", overflowX: "auto" }}
// //           >
// //             <Table stickyHeader>
// //               <TableHead>
// //                 <TableRow>
// //                   {columns.map((column, index) => (
// //                     <TableCell
// //                       key={index}
// //                       sx={{
// //                         fontWeight: "bold",
// //                         background: "#2a5353",
// //                         color: "white",
// //                       }}
// //                     >
// //                       {column}
// //                     </TableCell>
// //                   ))}
// //                 </TableRow>
// //               </TableHead>
// //               <TableBody>
// //                 {data
// //                   .slice(page * rowsPerPage, (page + 1) * rowsPerPage)
// //                   .map((row, rowIndex) => (
// //                     <TableRow key={rowIndex}>
// //                       {columns.map((col, colIndex) => (
// //                         <TableCell key={colIndex}>
// //                           {row[colIndex] || ""}
// //                         </TableCell>
// //                       ))}
// //                     </TableRow>
// //                   ))}
// //               </TableBody>
// //             </Table>
// //           </TableContainer>
// //         ) : (
// //           <Typography variant="h6" color="textSecondary" align="center">
// //             No data available. Upload a CSV/Excel file.
// //           </Typography>
// //         )}

// //         {/* Pagination (Hidden when expanded) */}
// //         {!expanded && data.length > 0 && (
// //           <TablePagination
// //             component="div"
// //             rowsPerPageOptions={[10]}
// //             count={data.length}
// //             rowsPerPage={rowsPerPage}
// //             page={page}
// //             onPageChange={(_, newPage) => setPage(newPage)}
// //           />
// //         )}
// //       </Paper>
// //     </Box>
// //   );
// // };

// // export default DataExplorer;

// // import React, { useState } from "react";
// // import * as XLSX from "xlsx";
// // import {
// //   Paper,
// //   Table,
// //   TableBody,
// //   TableCell,
// //   TableContainer,
// //   TableHead,
// //   TableRow,
// //   TablePagination,
// //   IconButton,
// //   Box,
// //   Button,
// //   Typography,
// // } from "@mui/material";
// // import ExpandMoreIcon from "@mui/icons-material/ExpandMore";
// // import ExpandLessIcon from "@mui/icons-material/ExpandLess";

// // const DataExplorer = () => {
// //   const [data, setData] = useState([]); // Table data
// //   const [columns, setColumns] = useState([]); // Column headers
// //   const [page, setPage] = useState(0);
// //   const [rowsPerPage, setRowsPerPage] = useState(10); // Default rows per page
// //   const [expanded, setExpanded] = useState(false);

// //   // Handle file upload
// //   const handleFileUpload = (event) => {
// //     const file = event.target.files[0];
// //     if (!file) return;

// //     const reader = new FileReader();
// //     reader.onload = (e) => {
// //       const binaryStr = e.target.result;
// //       const workbook = XLSX.read(binaryStr, { type: "binary" });
// //       const sheetName = workbook.SheetNames[0];
// //       const sheet = workbook.Sheets[sheetName];

// //       // Convert sheet to JSON
// //       const parsedData = XLSX.utils.sheet_to_json(sheet, { header: 1 });

// //       if (parsedData.length > 0) {
// //         setColumns(parsedData[0]); // First row as headers
// //         setData(parsedData.slice(1)); // Remaining rows as data
// //       }
// //     };
// //     reader.readAsBinaryString(file);
// //   };

// //   // Function to format Excel timestamp properly
// //   const formatExcelTimestamp = (value) => {
// //     if (!isNaN(value)) {
// //       const date = new Date((value - 25569) * 86400 * 1000); // Convert Excel serial to JS date
// //       return date.toLocaleString(); // Format date to readable format
// //     }
// //     return value;
// //   };

// //   return (
// //     <Box
// //       sx={{
// //         display: "flex",
// //         flexDirection: "column",
// //         alignItems: "center",
// //         gap: 2,
// //       }}
// //     >
// //       {/* File Upload Button */}
// //       <Button variant="contained" component="label">
// //         Upload CSV / Excel
// //         <input
// //           type="file"
// //           hidden
// //           accept=".csv, .xlsx, .xls"
// //           onChange={handleFileUpload}
// //         />
// //       </Button>

// //       {/* Expand/Collapse Button */}
// //       <IconButton onClick={() => setExpanded(!expanded)}>
// //         {expanded ? (
// //           <ExpandLessIcon fontSize="large" />
// //         ) : (
// //           <ExpandMoreIcon fontSize="large" />
// //         )}
// //       </IconButton>

// //       {/* Table */}
// //       <Paper
// //         sx={{
// //           width: expanded ? "90vw" : "600px",
// //           height: expanded ? "80vh" : "auto",
// //           overflow: "hidden",
// //           padding: 2,
// //           transition: "all 0.3s ease-in-out",
// //         }}
// //       >
// //         {data.length > 0 ? (
// //           <>
// //             <TableContainer
// //               sx={{ maxHeight: expanded ? "70vh" : "auto", overflowX: "auto" }}
// //             >
// //               <Table stickyHeader>
// //                 <TableHead>
// //                   <TableRow>
// //                     {columns.map((column, index) => (
// //                       <TableCell
// //                         key={index}
// //                         sx={{
// //                           fontWeight: "bold",
// //                           background: "#2a5353",
// //                           color: "white",
// //                           border: "1px solid black",
// //                         }}
// //                       >
// //                         {column}
// //                       </TableCell>
// //                     ))}
// //                   </TableRow>
// //                 </TableHead>
// //                 <TableBody>
// //                   {data
// //                     .slice(
// //                       page * rowsPerPage,
// //                       expanded ? data.length : (page + 1) * rowsPerPage
// //                     )
// //                     .map((row, rowIndex) => (
// //                       <TableRow key={rowIndex}>
// //                         {columns.map((col, colIndex) => (
// //                           <TableCell
// //                             key={colIndex}
// //                             sx={{ border: "1px solid black" }}
// //                           >
// //                             {col.toLowerCase().includes("timestamp")
// //                               ? formatExcelTimestamp(row[colIndex])
// //                               : row[colIndex] || ""}
// //                           </TableCell>
// //                         ))}
// //                       </TableRow>
// //                     ))}
// //                 </TableBody>
// //               </Table>
// //             </TableContainer>

// //             {/* Pagination (Always visible) */}
// //             {!expanded && (
// //               <TablePagination
// //                 component="div"
// //                 rowsPerPageOptions={[10, 20, 50]}
// //                 count={data.length}
// //                 rowsPerPage={rowsPerPage}
// //                 page={page}
// //                 onPageChange={(_, newPage) => setPage(newPage)}
// //                 onRowsPerPageChange={(e) => {
// //                   setRowsPerPage(parseInt(e.target.value, 10));
// //                   setPage(0);
// //                 }}
// //               />
// //             )}
// //           </>
// //         ) : (
// //           <Typography variant="h6" color="textSecondary" align="center">
// //             No data available. Upload a CSV/Excel file.
// //           </Typography>
// //         )}
// //       </Paper>
// //     </Box>
// //   );
// // };

// // export default DataExplorer;

// // import React, { useState } from "react";
// // import * as XLSX from "xlsx";
// // import {
// //   Paper,
// //   Table,
// //   TableBody,
// //   TableCell,
// //   TableContainer,
// //   TableHead,
// //   TableRow,
// //   TablePagination,
// //   IconButton,
// //   Box,
// //   Button,
// //   Typography,
// //   Select,
// //   MenuItem,
// //   FormControl,
// //   InputLabel,
// // } from "@mui/material";
// // import {
// //   LineChart,
// //   Line,
// //   XAxis,
// //   YAxis,
// //   Tooltip,
// //   CartesianGrid,
// //   ResponsiveContainer,
// // } from "recharts";
// // import ExpandMoreIcon from "@mui/icons-material/ExpandMore";
// // import ExpandLessIcon from "@mui/icons-material/ExpandLess";

// // const DataExplorer = () => {
// //   const [data, setData] = useState([]); // Table data
// //   const [columns, setColumns] = useState([]); // Column headers
// //   const [page, setPage] = useState(0);
// //   const [rowsPerPage, setRowsPerPage] = useState(10); // Default rows per page
// //   const [expanded, setExpanded] = useState(false);
// //   const [xAxis, setXAxis] = useState(""); // Selected X-axis
// //   const [yAxis, setYAxis] = useState(""); // Selected Y-axis

// //   // Handle file upload
// //   const handleFileUpload = (event) => {
// //     const file = event.target.files[0];
// //     if (!file) return;

// //     const reader = new FileReader();
// //     reader.onload = (e) => {
// //       const binaryStr = e.target.result;
// //       const workbook = XLSX.read(binaryStr, { type: "binary" });
// //       const sheetName = workbook.SheetNames[0];
// //       const sheet = workbook.Sheets[sheetName];

// //       // Convert sheet to JSON
// //       const parsedData = XLSX.utils.sheet_to_json(sheet, { header: 1 });

// //       if (parsedData.length > 0) {
// //         setColumns(parsedData[0]); // First row as headers
// //         setData(
// //           parsedData
// //             .slice(1)
// //             .map((row) =>
// //               Object.fromEntries(
// //                 parsedData[0].map((col, index) => [col, row[index]])
// //               )
// //             )
// //         ); // Convert to array of objects
// //       }
// //     };
// //     reader.readAsBinaryString(file);
// //   };

// //   return (
// //     <Box
// //       sx={{
// //         display: "flex",
// //         flexDirection: "column",
// //         alignItems: "center",
// //         gap: 2,
// //       }}
// //     >
// //       {/* File Upload Button */}
// //       <Button variant="contained" component="label">
// //         Upload CSV / Excel
// //         <input
// //           type="file"
// //           hidden
// //           accept=".csv, .xlsx, .xls"
// //           onChange={handleFileUpload}
// //         />
// //       </Button>

// //       {/* X-Axis and Y-Axis Selection */}
// //       <Box sx={{ display: "flex", gap: 2 }}>
// //         <FormControl sx={{ minWidth: 150 }}>
// //           <InputLabel>X-Axis</InputLabel>
// //           <Select value={xAxis} onChange={(e) => setXAxis(e.target.value)}>
// //             {columns.map((col, index) => (
// //               <MenuItem key={index} value={col}>
// //                 {col}
// //               </MenuItem>
// //             ))}
// //           </Select>
// //         </FormControl>

// //         <FormControl sx={{ minWidth: 150 }}>
// //           <InputLabel>Y-Axis</InputLabel>
// //           <Select value={yAxis} onChange={(e) => setYAxis(e.target.value)}>
// //             {columns.map((col, index) => (
// //               <MenuItem key={index} value={col}>
// //                 {col}
// //               </MenuItem>
// //             ))}
// //           </Select>
// //         </FormControl>
// //       </Box>

// //       {/* Expand/Collapse Button */}
// //       <IconButton onClick={() => setExpanded(!expanded)}>
// //         {expanded ? (
// //           <ExpandLessIcon fontSize="large" />
// //         ) : (
// //           <ExpandMoreIcon fontSize="large" />
// //         )}
// //       </IconButton>

// //       {/* Table */}
// //       <Paper
// //         sx={{
// //           width: expanded ? "90vw" : "600px",
// //           height: expanded ? "80vh" : "auto",
// //           overflow: "hidden",
// //           padding: 2,
// //           transition: "all 0.3s ease-in-out",
// //         }}
// //       >
// //         {data.length > 0 ? (
// //           <>
// //             <TableContainer
// //               sx={{ maxHeight: expanded ? "70vh" : "auto", overflowX: "auto" }}
// //             >
// //               <Table stickyHeader>
// //                 <TableHead>
// //                   <TableRow>
// //                     {columns.map((column, index) => (
// //                       <TableCell
// //                         key={index}
// //                         sx={{
// //                           fontWeight: "bold",
// //                           background: "#2a5353",
// //                           color: "white",
// //                           border: "1px solid black",
// //                         }}
// //                       >
// //                         {column}
// //                       </TableCell>
// //                     ))}
// //                   </TableRow>
// //                 </TableHead>
// //                 <TableBody>
// //                   {data
// //                     .slice(
// //                       page * rowsPerPage,
// //                       expanded ? data.length : (page + 1) * rowsPerPage
// //                     )
// //                     .map((row, rowIndex) => (
// //                       <TableRow key={rowIndex}>
// //                         {columns.map((col, colIndex) => (
// //                           <TableCell
// //                             key={colIndex}
// //                             sx={{ border: "1px solid black" }}
// //                           >
// //                             {row[col] || ""}
// //                           </TableCell>
// //                         ))}
// //                       </TableRow>
// //                     ))}
// //                 </TableBody>
// //               </Table>
// //             </TableContainer>

// //             {/* Pagination (Always visible) */}
// //             {!expanded && (
// //               <TablePagination
// //                 component="div"
// //                 rowsPerPageOptions={[10, 20, 50]}
// //                 count={data.length}
// //                 rowsPerPage={rowsPerPage}
// //                 page={page}
// //                 onPageChange={(_, newPage) => setPage(newPage)}
// //                 onRowsPerPageChange={(e) => {
// //                   setRowsPerPage(parseInt(e.target.value, 10));
// //                   setPage(0);
// //                 }}
// //               />
// //             )}
// //           </>
// //         ) : (
// //           <Typography variant="h6" color="textSecondary" align="center">
// //             No data available. Upload a CSV/Excel file.
// //           </Typography>
// //         )}
// //       </Paper>

// //       {/* Line Chart */}
// //       {xAxis && yAxis && data.length > 0 && (
// //         <Paper sx={{ width: "80vw", height: "400px", padding: 2 }}>
// //           <Typography variant="h6" align="center">
// //             Line Graph ({xAxis} vs {yAxis})
// //           </Typography>
// //           <ResponsiveContainer width="100%" height={350}>
// //             <LineChart data={data}>
// //               <CartesianGrid strokeDasharray="3 3" />
// //               <XAxis
// //                 dataKey={xAxis}
// //                 tickFormatter={(tick) => String(tick).slice(0, 10)}
// //               />
// //               <YAxis />
// //               <Tooltip />
// //               <Line
// //                 type="monotone"
// //                 dataKey={yAxis}
// //                 stroke="#8884d8"
// //                 strokeWidth={2}
// //                 dot={false}
// //               />
// //             </LineChart>
// //           </ResponsiveContainer>
// //         </Paper>
// //       )}
// //     </Box>
// //   );
// // };

// // export default DataExplorer;

// // import React, { useState } from "react";
// // import * as XLSX from "xlsx";
// // import {
// //   Paper,
// //   Table,
// //   TableBody,
// //   TableCell,
// //   TableContainer,
// //   TableHead,
// //   TableRow,
// //   TablePagination,
// //   IconButton,
// //   Box,
// //   Button,
// //   Typography,
// //   Select,
// //   MenuItem,
// //   FormControl,
// //   InputLabel,
// // } from "@mui/material";
// // import {
// //   LineChart,
// //   Line,
// //   XAxis,
// //   YAxis,
// //   Tooltip,
// //   CartesianGrid,
// //   ResponsiveContainer,
// // } from "recharts";
// // import ExpandMoreIcon from "@mui/icons-material/ExpandMore";
// // import ExpandLessIcon from "@mui/icons-material/ExpandLess";

// // const DataExplorer = () => {
// //   const [data, setData] = useState([]);
// //   const [columns, setColumns] = useState([]);
// //   const [page, setPage] = useState(0);
// //   const [rowsPerPage, setRowsPerPage] = useState(10);
// //   const [expanded, setExpanded] = useState(false);
// //   const [xAxis, setXAxis] = useState("");
// //   const [yAxis, setYAxis] = useState("");

// //   // Function to check if a value is a timestamp
// //   const isTimestamp = (value) => {
// //     return !isNaN(Date.parse(value)) || (!isNaN(value) && value > 10000);
// //   };

// //   // Function to format timestamp as 'YYYY-MM-DD'
// //   const formatDate = (value) => {
// //     if (!value) return value;

// //     // Handle Excel serial numbers (numeric timestamps)
// //     if (!isNaN(value) && value > 10000) {
// //       const excelEpoch = new Date(1899, 11, 30); // Excel's base date
// //       const date = new Date(excelEpoch.getTime() + value * 86400000);
// //       return date.toISOString().split("T")[0]; // Format as YYYY-MM-DD
// //     }

// //     // If it's already a date string, return it as is
// //     const parsedDate = Date.parse(value);
// //     if (!isNaN(parsedDate)) {
// //       return new Date(parsedDate).toISOString().split("T")[0]; // Ensure consistency
// //     }

// //     return value; // Return as is if not a date
// //   };

// //   // Handle file upload
// //   const handleFileUpload = (event) => {
// //     const file = event.target.files[0];
// //     if (!file) return;

// //     const reader = new FileReader();
// //     reader.onload = (e) => {
// //       const binaryStr = e.target.result;
// //       const workbook = XLSX.read(binaryStr, { type: "binary" });
// //       const sheetName = workbook.SheetNames[0];
// //       const sheet = workbook.Sheets[sheetName];

// //       // Convert sheet to JSON
// //       const parsedData = XLSX.utils.sheet_to_json(sheet, { header: 1 });

// //       if (parsedData.length > 0) {
// //         setColumns(parsedData[0]); // First row as headers
// //         setData(
// //           parsedData
// //             .slice(1)
// //             .map((row) =>
// //               Object.fromEntries(
// //                 parsedData[0].map((col, index) => [col, row[index]])
// //               )
// //             )
// //         ); // Convert to array of objects
// //       }
// //     };
// //     reader.readAsBinaryString(file);
// //   };

// //   return (
// //     <Box
// //       sx={{
// //         display: "flex",
// //         flexDirection: "column",
// //         alignItems: "center",
// //         gap: 2,
// //       }}
// //     >
// //       {/* File Upload Button */}
// //       <Button variant="contained" component="label">
// //         Upload CSV / Excel
// //         <input
// //           type="file"
// //           hidden
// //           accept=".csv, .xlsx, .xls"
// //           onChange={handleFileUpload}
// //         />
// //       </Button>

// //       {/* X-Axis and Y-Axis Selection */}
// //       <Box sx={{ display: "flex", gap: 2 }}>
// //         <FormControl sx={{ minWidth: 150 }}>
// //           <InputLabel>X-Axis</InputLabel>
// //           <Select value={xAxis} onChange={(e) => setXAxis(e.target.value)}>
// //             {columns.map((col, index) => (
// //               <MenuItem key={index} value={col}>
// //                 {col}
// //               </MenuItem>
// //             ))}
// //           </Select>
// //         </FormControl>

// //         <FormControl sx={{ minWidth: 150 }}>
// //           <InputLabel>Y-Axis</InputLabel>
// //           <Select value={yAxis} onChange={(e) => setYAxis(e.target.value)}>
// //             {columns.map((col, index) => (
// //               <MenuItem key={index} value={col}>
// //                 {col}
// //               </MenuItem>
// //             ))}
// //           </Select>
// //         </FormControl>
// //       </Box>

// //       {/* Expand/Collapse Button */}
// //       <IconButton onClick={() => setExpanded(!expanded)}>
// //         {expanded ? (
// //           <ExpandLessIcon fontSize="large" />
// //         ) : (
// //           <ExpandMoreIcon fontSize="large" />
// //         )}
// //       </IconButton>

// //       {/* Table */}
// //       <Paper
// //         sx={{
// //           width: expanded ? "90vw" : "600px",
// //           height: expanded ? "80vh" : "auto",
// //           overflow: "hidden",
// //           padding: 2,
// //           transition: "all 0.3s ease-in-out",
// //         }}
// //       >
// //         {data.length > 0 ? (
// //           <>
// //             <TableContainer sx={{ maxHeight: expanded ? "70vh" : "auto" }}>
// //               <Table stickyHeader>
// //                 <TableHead>
// //                   <TableRow>
// //                     {columns.map((column, index) => (
// //                       <TableCell
// //                         key={index}
// //                         sx={{
// //                           fontWeight: "bold",
// //                           background: "#2a5353",
// //                           color: "white",
// //                           border: "1px solid black",
// //                         }}
// //                       >
// //                         {column}
// //                       </TableCell>
// //                     ))}
// //                   </TableRow>
// //                 </TableHead>
// //                 <TableBody>
// //                   {data
// //                     .slice(
// //                       page * rowsPerPage,
// //                       expanded ? data.length : (page + 1) * rowsPerPage
// //                     )
// //                     .map((row, rowIndex) => (
// //                       <TableRow key={rowIndex}>
// //                         {columns.map((col, colIndex) => (
// //                           <TableCell
// //                             key={colIndex}
// //                             sx={{ border: "1px solid black" }}
// //                           >
// //                             {col === xAxis ? formatDate(row[col]) : row[col]}
// //                           </TableCell>
// //                         ))}
// //                       </TableRow>
// //                     ))}
// //                 </TableBody>
// //               </Table>
// //             </TableContainer>

// //             {/* Pagination */}
// //             {!expanded && (
// //               <TablePagination
// //                 component="div"
// //                 rowsPerPageOptions={[10, 20, 50]}
// //                 count={data.length}
// //                 rowsPerPage={rowsPerPage}
// //                 page={page}
// //                 onPageChange={(_, newPage) => setPage(newPage)}
// //                 onRowsPerPageChange={(e) => {
// //                   setRowsPerPage(parseInt(e.target.value, 10));
// //                   setPage(0);
// //                 }}
// //               />
// //             )}
// //           </>
// //         ) : (
// //           <Typography variant="h6" color="textSecondary" align="center">
// //             No data available. Upload a CSV/Excel file.
// //           </Typography>
// //         )}
// //       </Paper>

// //       {/* Line Chart */}
// //       {xAxis && yAxis && data.length > 0 && (
// //         <Paper sx={{ width: "80vw", height: "400px", padding: 2 }}>
// //           <Typography variant="h6" align="center">
// //             Line Graph ({xAxis} vs {yAxis})
// //           </Typography>
// //           <ResponsiveContainer width="100%" height={350}>
// //             <LineChart
// //               data={data.map((row) => ({
// //                 ...row,
// //                 [xAxis]: formatDate(row[xAxis]),
// //               }))}
// //             >
// //               <CartesianGrid strokeDasharray="3 3" />
// //               <XAxis dataKey={xAxis} />
// //               <YAxis />
// //               <Tooltip />
// //               <Line
// //                 type="step"
// //                 dataKey={yAxis}
// //                 stroke="#8884d8"
// //                 strokeWidth={2}
// //                 dot={false}
// //               />
// //             </LineChart>
// //           </ResponsiveContainer>
// //         </Paper>
// //       )}
// //     </Box>
// //   );
// // };

// // export default DataExplorer;
// // import React, { useState } from "react";
// // import * as XLSX from "xlsx";
// // import {
// //   Paper,
// //   Table,
// //   TableBody,
// //   TableCell,
// //   TableContainer,
// //   TableHead,
// //   TableRow,
// //   Button,
// //   Typography,
// //   Select,
// //   MenuItem,
// //   FormControl,
// //   InputLabel,
// //   Modal,
// //   Box,
// //   IconButton,
// // } from "@mui/material";
// // import {
// //   LineChart,
// //   Line,
// //   BarChart,
// //   Bar,
// //   AreaChart,
// //   Area,
// //   ScatterChart,
// //   Scatter,
// //   RadarChart,
// //   Radar,
// //   PolarGrid,
// //   PolarAngleAxis,
// //   PieChart,
// //   Pie,
// //   XAxis,
// //   YAxis,
// //   Tooltip,
// //   CartesianGrid,
// //   ResponsiveContainer,
// // } from "recharts";
// // import CloseIcon from "@mui/icons-material/Close";

// // const DataExplorer = () => {
// //   const [data, setData] = useState([]);
// //   const [columns, setColumns] = useState([]);
// //   const [xAxis, setXAxis] = useState("");
// //   const [yAxis, setYAxis] = useState("");
// //   const [chartType, setChartType] = useState("");
// //   const [openModal, setOpenModal] = useState(false);

// //   const chartTypes = ["Line", "Bar", "Area", "Scatter", "Radar", "Pie"];

// //   // Handle file upload
// //   const handleFileUpload = (event) => {
// //     const file = event.target.files[0];
// //     if (!file) return;
// //     const reader = new FileReader();
// //     reader.onload = (e) => {
// //       const binaryStr = e.target.result;
// //       const workbook = XLSX.read(binaryStr, { type: "binary" });
// //       const sheetName = workbook.SheetNames[0];
// //       const sheet = workbook.Sheets[sheetName];
// //       const parsedData = XLSX.utils.sheet_to_json(sheet, { header: 1 });

// //       if (parsedData.length > 0) {
// //         setColumns(parsedData[0]);
// //         setData(
// //           parsedData
// //             .slice(1)
// //             .map((row) =>
// //               Object.fromEntries(
// //                 parsedData[0].map((col, index) => [col, row[index]])
// //               )
// //             )
// //         );
// //       }
// //     };
// //     reader.readAsBinaryString(file);
// //   };

// //   // Check if all selections are made
// //   const handleShowGraph = () => {
// //     if (xAxis && yAxis && chartType) {
// //       setOpenModal(true);
// //     } else {
// //       alert(
// //         "Please select X-Axis, Y-Axis, and Chart Type before viewing the graph."
// //       );
// //     }
// //   };

// //   return (
// //     <Box
// //       sx={{
// //         display: "flex",
// //         flexDirection: "column",
// //         alignItems: "center",
// //         gap: 2,
// //         width: "90%",
// //       }}
// //     >
// //       {/* File Upload */}
// //       <Button variant="contained" component="label">
// //         Upload CSV / Excel
// //         <input
// //           type="file"
// //           hidden
// //           accept=".csv, .xlsx, .xls"
// //           onChange={handleFileUpload}
// //         />
// //       </Button>

// //       {/* Dropdowns for X-Axis, Y-Axis, and Chart Type */}
// //       <Box sx={{ display: "flex", gap: 2 }}>
// //         <FormControl sx={{ minWidth: 150 }}>
// //           <InputLabel>X-Axis</InputLabel>
// //           <Select value={xAxis} onChange={(e) => setXAxis(e.target.value)}>
// //             {columns.map((col, index) => (
// //               <MenuItem key={index} value={col}>
// //                 {col}
// //               </MenuItem>
// //             ))}
// //           </Select>
// //         </FormControl>

// //         <FormControl sx={{ minWidth: 150 }}>
// //           <InputLabel>Y-Axis</InputLabel>
// //           <Select value={yAxis} onChange={(e) => setYAxis(e.target.value)}>
// //             {columns.map((col, index) => (
// //               <MenuItem key={index} value={col}>
// //                 {col}
// //               </MenuItem>
// //             ))}
// //           </Select>
// //         </FormControl>

// //         <FormControl sx={{ minWidth: 150 }}>
// //           <InputLabel>Chart Type</InputLabel>
// //           <Select
// //             value={chartType}
// //             onChange={(e) => setChartType(e.target.value)}
// //           >
// //             {chartTypes.map((type) => (
// //               <MenuItem key={type} value={type}>
// //                 {type}
// //               </MenuItem>
// //             ))}
// //           </Select>
// //         </FormControl>

// //         {/* Button to open graph pop-up */}
// //         <Button variant="contained" onClick={handleShowGraph}>
// //           View Graph
// //         </Button>
// //       </Box>

// //       {/* Table Display */}
// //       {data.length > 0 && (
// //         <TableContainer
// //           component={Paper}
// //           sx={{ maxHeight: 300, overflowY: "auto", mt: 2 }}
// //         >
// //           <Table stickyHeader>
// //             <TableHead>
// //               <TableRow>
// //                 {columns.map((col, index) => (
// //                   <TableCell key={index} sx={{ fontWeight: "bold" }}>
// //                     {col}
// //                   </TableCell>
// //                 ))}
// //               </TableRow>
// //             </TableHead>
// //             <TableBody>
// //               {data.slice(0, 10).map((row, rowIndex) => (
// //                 <TableRow key={rowIndex}>
// //                   {columns.map((col, colIndex) => (
// //                     <TableCell key={colIndex}>{row[col]}</TableCell>
// //                   ))}
// //                 </TableRow>
// //               ))}
// //             </TableBody>
// //           </Table>
// //         </TableContainer>
// //       )}

// //       {/* Modal for Graph */}
// //       <Modal open={openModal} onClose={() => setOpenModal(false)}>
// //         <Box
// //           sx={{
// //             position: "absolute",
// //             top: "50%",
// //             left: "50%",
// //             transform: "translate(-50%, -50%)",
// //             width: "70vw",
// //             bgcolor: "background.paper",
// //             boxShadow: 24,
// //             p: 4,
// //             borderRadius: 2,
// //           }}
// //         >
// //           {/* Modal Header */}
// //           <Box
// //             sx={{
// //               display: "flex",
// //               justifyContent: "space-between",
// //               alignItems: "center",
// //             }}
// //           >
// //             <Typography variant="h6">
// //               {chartType} Chart ({xAxis} vs {yAxis})
// //             </Typography>
// //             <IconButton onClick={() => setOpenModal(false)}>
// //               <CloseIcon />
// //             </IconButton>
// //           </Box>

// //           {/* Graph Display */}
// //           <ResponsiveContainer width="100%" height={400}>
// //             {chartType === "Line" && (
// //               <LineChart data={data}>
// //                 <XAxis dataKey={xAxis} />
// //                 <YAxis />
// //                 <Tooltip />
// //                 <CartesianGrid stroke="#ccc" />
// //                 <Line type="monotone" dataKey={yAxis} stroke="#8884d8" />
// //               </LineChart>
// //             )}
// //             {chartType === "Bar" && (
// //               <BarChart data={data}>
// //                 <XAxis dataKey={xAxis} />
// //                 <YAxis />
// //                 <Tooltip />
// //                 <CartesianGrid stroke="#ccc" />
// //                 <Bar dataKey={yAxis} fill="#8884d8" />
// //               </BarChart>
// //             )}
// //             {chartType === "Area" && (
// //               <AreaChart data={data}>
// //                 <XAxis dataKey={xAxis} />
// //                 <YAxis />
// //                 <Tooltip />
// //                 <CartesianGrid stroke="#ccc" />
// //                 <Area dataKey={yAxis} fill="#82ca9d" />
// //               </AreaChart>
// //             )}
// //             {chartType === "Scatter" && (
// //               <ScatterChart>
// //                 <XAxis dataKey={xAxis} />
// //                 <YAxis />
// //                 <Tooltip />
// //                 <Scatter data={data} dataKey={yAxis} fill="#8884d8" />
// //               </ScatterChart>
// //             )}
// //             {chartType === "Radar" && (
// //               <RadarChart data={data}>
// //                 <PolarGrid />
// //                 <PolarAngleAxis dataKey={xAxis} />
// //                 <Radar name={yAxis} dataKey={yAxis} fill="#8884d8" />
// //               </RadarChart>
// //             )}
// //             {chartType === "Pie" && (
// //               <PieChart>
// //                 <Tooltip />
// //                 <Pie
// //                   data={data}
// //                   dataKey={yAxis}
// //                   nameKey={xAxis}
// //                   fill="#8884d8"
// //                   label
// //                 />
// //               </PieChart>
// //             )}
// //           </ResponsiveContainer>
// //         </Box>
// //       </Modal>
// //     </Box>
// //   );
// // };

// // export default DataExplorer;
// import React, { useState } from "react";
// import * as XLSX from "xlsx";
// import {
//   Paper,
//   Table,
//   TableBody,
//   TableCell,
//   TableContainer,
//   TableHead,
//   TableRow,
//   Button,
//   Typography,
//   Select,
//   MenuItem,
//   FormControl,
//   InputLabel,
//   Modal,
//   Box,
//   IconButton,
//   CircularProgress,
// } from "@mui/material";
// import {
//   LineChart,
//   Line,
//   BarChart,
//   Bar,
//   AreaChart,
//   Area,
//   ScatterChart,
//   Scatter,
//   RadarChart,
//   Radar,
//   PolarGrid,
//   PolarAngleAxis,
//   PieChart,
//   Pie,
//   XAxis,
//   YAxis,
//   Tooltip,
//   CartesianGrid,
//   ResponsiveContainer,
// } from "recharts";
// import CloseIcon from "@mui/icons-material/Close";

// const DataExplorer = () => {
//   const [data, setData] = useState([]);
//   const [columns, setColumns] = useState([]);
//   const [xAxis, setXAxis] = useState("");
//   const [yAxis, setYAxis] = useState("");
//   const [chartType, setChartType] = useState("");
//   const [openModal, setOpenModal] = useState(false);
//   const [loading, setLoading] = useState(false);

//   const chartTypes = ["Line", "Bar", "Area", "Scatter", "Radar", "Pie"];

//   // Handle file upload
//   const handleFileUpload = (event) => {
//     setLoading(true);
//     const file = event.target.files[0];
//     if (!file) return;
//     const reader = new FileReader();
//     reader.onload = (e) => {
//       const binaryStr = e.target.result;
//       const workbook = XLSX.read(binaryStr, { type: "binary" });
//       const sheetName = workbook.SheetNames[0];
//       const sheet = workbook.Sheets[sheetName];
//       const parsedData = XLSX.utils.sheet_to_json(sheet, { header: 1 });

//       if (parsedData.length > 0) {
//         setColumns(parsedData[0]);
//         setData(
//           parsedData
//             .slice(1)
//             .map((row) =>
//               Object.fromEntries(
//                 parsedData[0].map((col, index) => [col, row[index]]),
//               ),
//             ),
//         );
//       }
//       setLoading(false);
//     };
//     reader.readAsBinaryString(file);
//   };

//   // Check if all selections are made
//   const handleShowGraph = () => {
//     if (xAxis && yAxis && chartType) {
//       setOpenModal(true);
//     } else {
//       alert("Please select X-Axis, Y-Axis, and Chart Type before viewing the graph.");
//     }
//   };

//   return (
//     <Box sx={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 2, width: "90%" }}>
//       {/* File Upload */}
//       <Button variant="contained" component="label" sx={{ marginBottom: 3 }}>
//         Upload CSV / Excel
//         <input
//           type="file"
//           hidden
//           accept=".csv, .xlsx, .xls"
//           onChange={handleFileUpload}
//         />
//       </Button>

//       {/* Loading Indicator */}
//       {loading && <CircularProgress sx={{ marginBottom: 2 }} />}

//       {/* Dropdowns for X-Axis, Y-Axis, and Chart Type */}
//       <Box sx={{ display: "flex", gap: 2, marginBottom: 3 }}>
//         <FormControl sx={{ minWidth: 150 }}>
//           <InputLabel>X-Axis</InputLabel>
//           <Select value={xAxis} onChange={(e) => setXAxis(e.target.value)}>
//             {columns.map((col, index) => (
//               <MenuItem key={index} value={col}>
//                 {col}
//               </MenuItem>
//             ))}
//           </Select>
//         </FormControl>

//         <FormControl sx={{ minWidth: 150 }}>
//           <InputLabel>Y-Axis</InputLabel>
//           <Select value={yAxis} onChange={(e) => setYAxis(e.target.value)}>
//             {columns.map((col, index) => (
//               <MenuItem key={index} value={col}>
//                 {col}
//               </MenuItem>
//             ))}
//           </Select>
//         </FormControl>

//         <FormControl sx={{ minWidth: 150 }}>
//           <InputLabel>Chart Type</InputLabel>
//           <Select value={chartType} onChange={(e) => setChartType(e.target.value)}>
//             {chartTypes.map((type) => (
//               <MenuItem key={type} value={type}>
//                 {type}
//               </MenuItem>
//             ))}
//           </Select>
//         </FormControl>

//         {/* Button to open graph pop-up */}
//         <Button variant="contained" onClick={handleShowGraph}>
//           View Graph
//         </Button>
//       </Box>

//       {/* Table Display */}
//       {data.length > 0 && !loading && (
//         <TableContainer component={Paper} sx={{ maxHeight: 300, overflowY: "auto", mt: 2 }}>
//           <Table stickyHeader>
//             <TableHead>
//               <TableRow>
//                 {columns.map((col, index) => (
//                   <TableCell key={index} sx={{ fontWeight: "bold" }}>
//                     {col}
//                   </TableCell>
//                 ))}
//               </TableRow>
//             </TableHead>
//             <TableBody>
//               {data.slice(0, 10).map((row, rowIndex) => (
//                 <TableRow key={rowIndex}>
//                   {columns.map((col, colIndex) => (
//                     <TableCell key={colIndex}>{row[col]}</TableCell>
//                   ))}
//                 </TableRow>
//               ))}
//             </TableBody>
//           </Table>
//         </TableContainer>
//       )}

//       {/* Modal for Graph */}
//       <Modal open={openModal} onClose={() => setOpenModal(false)}>
//         <Box
//           sx={{
//             position: "absolute",
//             top: "50%",
//             left: "50%",
//             transform: "translate(-50%, -50%)",
//             width: "70vw",
//             bgcolor: "background.paper",
//             boxShadow: 24,
//             p: 4,
//             borderRadius: 2,
//           }}
//         >
//           {/* Modal Header */}
//           <Box sx={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
//             <Typography variant="h6">
//               {chartType} Chart ({xAxis} vs {yAxis})
//             </Typography>
//             <IconButton onClick={() => setOpenModal(false)}>
//               <CloseIcon />
//             </IconButton>
//           </Box>

//           {/* Graph Display */}
//           <ResponsiveContainer width="100%" height={400}>
//             {chartType === "Line" && (
//               <LineChart data={data}>
//                 <XAxis dataKey={xAxis} />
//                 <YAxis />
//                 <Tooltip />
//                 <CartesianGrid stroke="#ccc" />
//                 <Line type="monotone" dataKey={yAxis} stroke="#8884d8" />
//               </LineChart>
//             )}
//             {chartType === "Bar" && (
//               <BarChart data={data}>
//                 <XAxis dataKey={xAxis} />
//                 <YAxis />
//                 <Tooltip />
//                 <CartesianGrid stroke="#ccc" />
//                 <Bar dataKey={yAxis} fill="#8884d8" />
//               </BarChart>
//             )}
//             {chartType === "Area" && (
//               <AreaChart data={data}>
//                 <XAxis dataKey={xAxis} />
//                 <YAxis />
//                 <Tooltip />
//                 <CartesianGrid stroke="#ccc" />
//                 <Area dataKey={yAxis} fill="#82ca9d" />
//               </AreaChart>
//             )}
//             {chartType === "Scatter" && (
//               <ScatterChart>
//                 <XAxis dataKey={xAxis} />
//                 <YAxis />
//                 <Tooltip />
//                 <Scatter data={data} dataKey={yAxis} fill="#8884d8" />
//               </ScatterChart>
//             )}
//             {chartType === "Radar" && (
//               <RadarChart data={data}>
//                 <PolarGrid />
//                 <PolarAngleAxis dataKey={xAxis} />
//                 <Radar name={yAxis} dataKey={yAxis} fill="#8884d8" />
//               </RadarChart>
//             )}
//             {chartType === "Pie" && (
//               <PieChart>
//                 <Tooltip />
//                 <Pie data={data} dataKey={yAxis} nameKey={xAxis} fill="#8884d8" label />
//               </PieChart>
//             )}
//           </ResponsiveContainer>
//         </Box>
//       </Modal>
//     </Box>
//   );
// };

// export default DataExplorer;


import React, { useState, useEffect } from "react";
import {
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Button,
  Typography,
  Select,
  MenuItem,
  FormControl,
  InputLabel,
  Modal,
  Box,
  IconButton,
  CircularProgress,
} from "@mui/material";
import {
  LineChart,
  Line,
  BarChart,
  Bar,
  AreaChart,
  Area,
  ScatterChart,
  Scatter,
  RadarChart,
  Radar,
  PolarGrid,
  PolarAngleAxis,
  PieChart,
  Pie,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  ResponsiveContainer,
} from "recharts";
import CloseIcon from "@mui/icons-material/Close";

const DataExplorer = () => {
  const [data, setData] = useState([]);
  const [columns, setColumns] = useState([]);
  const [xAxis, setXAxis] = useState("");
  const [yAxis, setYAxis] = useState("");
  const [chartType, setChartType] = useState("");
  const [openModal, setOpenModal] = useState(false);
  const [loading, setLoading] = useState(true);

  const chartTypes = ["Line", "Bar", "Area", "Scatter", "Radar", "Pie"];

  // Fetch data from API
  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await fetch("http://127.0.0.1:8000/data/");
        const jsonData = await response.json();
        if (jsonData.length > 0) {
          setColumns(Object.keys(jsonData[0]));
          setData(jsonData);
        }
      } catch (error) {
        console.error("Error fetching data:", error);
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, []);

  // Check if all selections are made
  const handleShowGraph = () => {
    if (xAxis && yAxis && chartType) {
      setOpenModal(true);
    } else {
      alert("Please select X-Axis, Y-Axis, and Chart Type before viewing the graph.");
    }
  };

  return (
    <Box sx={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 2, width: "90%" }}>
      {/* Loading Indicator */}
      {loading && <CircularProgress sx={{ marginBottom: 2 }} />}

      {/* Dropdowns for X-Axis, Y-Axis, and Chart Type */}
      <Box sx={{ display: "flex", gap: 2, marginBottom: 3 }}>
        <FormControl sx={{ minWidth: 150 }}>
          <InputLabel>X-Axis</InputLabel>
          <Select value={xAxis} onChange={(e) => setXAxis(e.target.value)}>
            {columns.map((col, index) => (
              <MenuItem key={index} value={col}>
                {col}
              </MenuItem>
            ))}
          </Select>
        </FormControl>

        <FormControl sx={{ minWidth: 150 }}>
          <InputLabel>Y-Axis</InputLabel>
          <Select value={yAxis} onChange={(e) => setYAxis(e.target.value)}>
            {columns.map((col, index) => (
              <MenuItem key={index} value={col}>
                {col}
              </MenuItem>
            ))}
          </Select>
        </FormControl>

        <FormControl sx={{ minWidth: 150 }}>
          <InputLabel>Chart Type</InputLabel>
          <Select value={chartType} onChange={(e) => setChartType(e.target.value)}>
            {chartTypes.map((type) => (
              <MenuItem key={type} value={type}>
                {type}
              </MenuItem>
            ))}
          </Select>
        </FormControl>

        {/* Button to open graph pop-up */}
        <Button variant="contained" onClick={handleShowGraph}>
          View Graph
        </Button>
      </Box>

      {/* Table Display */}
      {data.length > 0 && !loading && (
        <TableContainer component={Paper} sx={{ maxHeight: 300, overflowY: "auto", mt: 2 }}>
          <Table stickyHeader>
            <TableHead>
              <TableRow>
                {columns.map((col, index) => (
                  <TableCell key={index} sx={{ fontWeight: "bold" }}>
                    {col}
                  </TableCell>
                ))}
              </TableRow>
            </TableHead>
            <TableBody>
              {data.slice(0, 10).map((row, rowIndex) => (
                <TableRow key={rowIndex}>
                  {columns.map((col, colIndex) => (
                    <TableCell key={colIndex}>{row[col]}</TableCell>
                  ))}
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
      )}

      {/* Modal for Graph */}
      <Modal open={openModal} onClose={() => setOpenModal(false)}>
        <Box
          sx={{
            position: "absolute",
            top: "50%",
            left: "50%",
            transform: "translate(-50%, -50%)",
            width: "70vw",
            bgcolor: "background.paper",
            boxShadow: 24,
            p: 4,
            borderRadius: 2,
          }}
        >
          {/* Modal Header */}
          <Box sx={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
            <Typography variant="h6">
              {chartType} Chart ({xAxis} vs {yAxis})
            </Typography>
            <IconButton onClick={() => setOpenModal(false)}>
              <CloseIcon />
            </IconButton>
          </Box>

          {/* Graph Display */}
          <ResponsiveContainer width="100%" height={400}>
            {chartType === "Line" && (
              <LineChart data={data}>
                <XAxis dataKey={xAxis} />
                <YAxis />
                <Tooltip />
                <CartesianGrid stroke="#ccc" />
                <Line type="monotone" dataKey={yAxis} stroke="#8884d8" />
              </LineChart>
            )}
            {chartType === "Bar" && (
              <BarChart data={data}>
                <XAxis dataKey={xAxis} />
                <YAxis />
                <Tooltip />
                <CartesianGrid stroke="#ccc" />
                <Bar dataKey={yAxis} fill="#8884d8" />
              </BarChart>
            )}
            {chartType === "Area" && (
              <AreaChart data={data}>
                <XAxis dataKey={xAxis} />
                <YAxis />
                <Tooltip />
                <CartesianGrid stroke="#ccc" />
                <Area dataKey={yAxis} fill="#82ca9d" />
              </AreaChart>
            )}
            {chartType === "Scatter" && (
              <ScatterChart>
                <XAxis dataKey={xAxis} />
                <YAxis />
                <Tooltip />
                <Scatter data={data} dataKey={yAxis} fill="#8884d8" />
              </ScatterChart>
            )}
            {chartType === "Radar" && (
              <RadarChart data={data}>
                <PolarGrid />
                <PolarAngleAxis dataKey={xAxis} />
                <Radar name={yAxis} dataKey={yAxis} fill="#8884d8" />
              </RadarChart>
            )}
            {chartType === "Pie" && (
              <PieChart>
                <Tooltip />
                <Pie data={data} dataKey={yAxis} nameKey={xAxis} fill="#8884d8" label />
              </PieChart>
            )}
          </ResponsiveContainer>
        </Box>
      </Modal>
    </Box>
  );
};

export default DataExplorer;
