import React from "react";
export default function Prediction() {
  return <h1>🔮 Prediction Page</h1>;
}
