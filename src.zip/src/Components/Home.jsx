// import React, { useState, useRef } from "react";
// import {
//   Typography,
//   Card,
//   CardContent,
//   Box,
//   Modal,
//   IconButton,
// } from "@mui/material";
// import { Swiper, SwiperSlide } from "swiper/react";
// import { Navigation, Pagination, Autoplay } from "swiper/modules";
// import { motion } from "framer-motion"; // Animation library
// import CloseIcon from "@mui/icons-material/Close";
// import "swiper/css";
// import "swiper/css/navigation";
// import "swiper/css/pagination";
// import BatteryChargingFullIcon from "@mui/icons-material/BatteryChargingFull";
// import SpeedIcon from "@mui/icons-material/Speed";
// import SyncIcon from "@mui/icons-material/Sync";
// import AcUnitIcon from "@mui/icons-material/AcUnit";
// import ElectricCarIcon from "@mui/icons-material/ElectricCar";
// import RotateRightIcon from "@mui/icons-material/RotateRight";
// import TerrainIcon from "@mui/icons-material/Terrain";
// import HeightIcon from "@mui/icons-material/Height";
// import DeviceThermostatIcon from "@mui/icons-material/DeviceThermostat";
// import EvStationIcon from "@mui/icons-material/EvStation";
// import AirIcon from "@mui/icons-material/Air";
// import GpsFixedIcon from "@mui/icons-material/GpsFixed";

// const dataPoints = [
//   {
//     title: "ELV Spy",
//     description: "Real-time monitoring of vehicle battery.",
//     icon: <EvStationIcon fontSize="large" />,
//   },
//   {
//     title: "Speed",
//     description: "Current vehicle speed.",
//     icon: <SpeedIcon fontSize="large" />,
//   },
//   {
//     title: "SOC",
//     description: "State of Charge - Battery remaining in %.",
//     icon: <BatteryChargingFullIcon fontSize="large" />,
//   },
//   {
//     title: "Ambient Temperature",
//     description: "External temperature affecting efficiency.",
//     icon: <AcUnitIcon fontSize="large" />,
//   },
//   {
//     title: "Regenerated Energy",
//     description: "Energy recovered via regenerative braking.",
//     icon: <SyncIcon fontSize="large" />,
//   },
//   {
//     title: "Motor Power (W)",
//     description: "Power output from the motor.",
//     icon: <ElectricCarIcon fontSize="large" />,
//   },
//   {
//     title: "Motor Temperature",
//     description: "Temperature of the EV’s motor.",
//     icon: <DeviceThermostatIcon fontSize="large" />,
//   },
//   {
//     title: "Torque (Nm)",
//     description: "Rotational force applied by the motor.",
//     icon: <SyncIcon fontSize="large" />,
//   },
//   {
//     title: "RPM",
//     description: "Motor speed in revolutions per minute.",
//     icon: <RotateRightIcon fontSize="large" />,
//   },
//   {
//     title: "Wind Speed (mph)",
//     description: "Wind speed affecting aerodynamics.",
//     icon: <AirIcon fontSize="large" />,
//   },
//   {
//     title: "Altitude",
//     description: "Height above sea level.",
//     icon: <HeightIcon fontSize="large" />,
//   },
//   {
//     title: "Slope (º)",
//     description: "Incline/decline of the road.",
//     icon: <TerrainIcon fontSize="large" />,
//   },
//   {
//     title: "Longitude",
//     description: "Geographical position (Longitude).",
//     icon: <GpsFixedIcon fontSize="large" />,
//   },
//   {
//     title: "Latitude",
//     description: "Geographical position (Latitude).",
//     icon: <GpsFixedIcon fontSize="large" />,
//   },
//   {
//     title: "Remaining Range (km)",
//     description: "Estimated distance left before battery depletion.",
//     icon: <BatteryChargingFullIcon fontSize="large" />,
//   },
// ];

// function DataCard({ title, description, icon, onClick }) {
//   return (
//     <motion.div
//       initial={{ y: 100, opacity: 0 }}
//       animate={{ y: 0, opacity: 1 }}
//       transition={{ duration: 0.6 }}
//     >
//       <Card
//         sx={{
//           width: 250,
//           height: 160,
//           display: "flex",
//           flexDirection: "column",
//           alignItems: "center",
//           justifyContent: "center",
//           textAlign: "center",
//           borderRadius: 3,
//           p: 2,
//           background: "linear-gradient(135deg, #ffffff, #f7f7f7)",
//           color: "#333",
//           transition: "transform 0.4s ease, box-shadow 0.4s ease",
//           cursor: "pointer",
//           "&:hover": {
//             transform: "scale(1.05)",
//             boxShadow: "0px 8px 20px rgba(0, 153, 255, 0.3)",
//           },
//         }}
//         onClick={onClick} // Open popup on click
//       >
//         <CardContent sx={{ textAlign: "center" }}>
//           {icon}
//           <Typography
//             variant="h6"
//             sx={{ mt: 1, fontSize: "1rem", fontWeight: 600 }}
//           >
//             {title}
//           </Typography>
//         </CardContent>
//       </Card>
//     </motion.div>
//   );
// }

// export default function Home() {
//   const swiperRef = useRef(null);
//   const [selectedData, setSelectedData] = useState(null); // Track clicked card

//   return (
//     <Box sx={{ padding: "20px", maxWidth: "90%", margin: "auto" }}>
//       <Typography
//         variant="h4"
//         sx={{ mb: 2, textAlign: "center", color: "#333" }}
//       >
//         🏠 EV Battery Optimization
//       </Typography>

//       <Swiper
//         slidesPerView={4}
//         spaceBetween={20}
//         navigation={true}
//         pagination={{ clickable: true }}
//         autoplay={{ delay: 3000, disableOnInteraction: false }}
//         modules={[Navigation, Pagination, Autoplay]}
//         onSwiper={(swiper) => (swiperRef.current = swiper)}
//         style={{ paddingBottom: "60px" }} // Space below cards
//       >
//         {dataPoints.map((item, index) => (
//           <SwiperSlide key={index}>
//             <DataCard {...item} onClick={() => setSelectedData(item)} />
//           </SwiperSlide>
//         ))}
//       </Swiper>

//       {/* Modal for showing full content */}
//       <Modal
//         open={!!selectedData}
//         onClose={() => setSelectedData(null)}
//         sx={{
//           display: "flex",
//           alignItems: "center",
//           justifyContent: "center",
//         }}
//       >
//         <motion.div
//           initial={{ scale: 0.7, opacity: 0 }}
//           animate={{ scale: 1, opacity: 1 }}
//           transition={{ duration: 0.4 }}
//           style={{
//             background: "#fff",
//             padding: "20px",
//             borderRadius: "12px",
//             boxShadow: "0px 10px 30px rgba(0,0,0,0.2)",
//             maxWidth: "400px",
//             textAlign: "center",
//             position: "relative",
//           }}
//         >
//           <IconButton
//             onClick={() => setSelectedData(null)}
//             sx={{ position: "absolute", top: 10, right: 10 }}
//           >
//             <CloseIcon />
//           </IconButton>

//           {selectedData?.icon}
//           <Typography variant="h5" sx={{ mt: 1, fontWeight: "bold" }}>
//             {selectedData?.title}
//           </Typography>
//           <Typography variant="body1" sx={{ mt: 2, color: "#666" }}>
//             {selectedData?.description}
//           </Typography>
//         </motion.div>
//       </Modal>
//     </Box>
//   );
// }

// import React, { useState, useRef } from "react";
// import {
//   Typography,
//   Card,
//   CardContent,
//   Box,
//   Modal,
//   IconButton,
// } from "@mui/material";
// import { Swiper, SwiperSlide } from "swiper/react";
// import { Navigation, Pagination, Autoplay } from "swiper/modules";
// import { motion } from "framer-motion"; // Animation library
// import CloseIcon from "@mui/icons-material/Close";
// import "swiper/css";
// import "swiper/css/navigation";
// import "swiper/css/pagination";
// import HomeBackground from "../Assets/Background Images/HomeBackground.webp";
// import {
//   EvStation as EvStationIcon,
//   Speed as SpeedIcon,
//   BatteryChargingFull as BatteryIcon,
//   AcUnit as AcUnitIcon,
//   Sync as SyncIcon,
//   DeviceThermostat as ThermostatIcon,
//   Air as AirIcon,
//   Height as HeightIcon,
//   GpsFixed as GpsIcon,
//   DirectionsCar as CarIcon,
//   FlashOn as FlashIcon,
//   Speed as RpmIcon,
//   Storage as DataIcon,
//   Timeline as GraphIcon,
//   LocationOn as LocationIcon,
//   CompareArrows as SlopeIcon,
//   RotateRight as TorqueIcon,
// } from "@mui/icons-material";

// // Data Points
// const dataPoints = [
//   {
//     title: "ELV Spy",
//     description:
//       "Monitors battery voltage, current, and temperature in real-time. Early detection of fluctuations helps prevent rapid degradation.",
//     icon: <EvStationIcon />,
//   },
//   {
//     title: "Speed",
//     description:
//       "High speeds cause excessive battery discharge cycles, accelerating capacity loss. Maintaining moderate speeds improves longevity.",
//     icon: <SpeedIcon />,
//   },
//   {
//     title: "SOC (State of Charge)",
//     description:
//       "Extreme SOC levels (0% or 100%) stress battery cells, reducing lifespan. Keeping SOC between 20-80% optimizes health.",
//     icon: <BatteryIcon />,
//   },
//   {
//     title: "Ambient Temperature",
//     description:
//       "High temperatures accelerate chemical degradation, while cold reduces charge efficiency. Thermal management stabilizes SOH.",
//     icon: <AcUnitIcon />,
//   },
//   {
//     title: "Regenerated Energy (Wh)",
//     description:
//       "Efficient regenerative braking reduces deep discharge cycles, improving overall battery lifespan.",
//     icon: <SyncIcon />,
//   },
//   {
//     title: "Motor Power (W)",
//     description:
//       "High power output increases heat and battery stress. Smooth acceleration reduces strain and extends lifespan.",
//     icon: <FlashIcon />,
//   },
//   {
//     title: "Aux Power (100W)",
//     description:
//       "Excessive auxiliary power drains the battery, reducing available energy for driving. Optimizing power consumption preserves range.",
//     icon: <DataIcon />,
//   },
//   {
//     title: "Motor Temperature",
//     description:
//       "Overheating can cause thermal runaway, permanently damaging the battery. Proper cooling systems prevent overheating.",
//     icon: <ThermostatIcon />,
//   },
//   {
//     title: "Torque (Nm)",
//     description:
//       "High torque demand leads to rapid battery discharge, affecting SOH. Gentle acceleration minimizes strain on cells.",
//     icon: <TorqueIcon />,
//   },
//   {
//     title: "RPM",
//     description:
//       "High RPM increases heat and energy loss, leading to inefficiency. Optimizing gear ratios and driving habits improves SOH.",
//     icon: <RpmIcon />,
//   },
//   {
//     title: "Battery Capacity",
//     description:
//       "Frequent deep discharges reduce battery capacity over time. Partial charging strategies slow down SOH decline.",
//     icon: <BatteryIcon />,
//   },
//   {
//     title: "Reference Consumption",
//     description:
//       "High energy consumption drains the battery faster, reducing cycle life. Efficient driving techniques enhance SOH.",
//     icon: <GraphIcon />,
//   },
//   {
//     title: "Wind Speed (mph & kph)",
//     description:
//       "Strong winds increase resistance, requiring more power and shortening battery lifespan. Adjusting speed reduces drag effects.",
//     icon: <AirIcon />,
//   },
//   {
//     title: "Wind Degree",
//     description:
//       "Crosswinds increase energy usage, leading to faster discharge. Predictive driving can minimize energy waste.",
//     icon: <AirIcon />,
//   },
//   {
//     title: "Frontal Wind",
//     description:
//       "Headwinds force the motor to work harder, increasing energy demand. Lower speeds reduce wind resistance and save energy.",
//     icon: <AirIcon />,
//   },
//   {
//     title: "Vehicle Angle",
//     description:
//       "Steep inclines demand more power, depleting battery faster. Regenerative braking helps recover energy downhill.",
//     icon: <CarIcon />,
//   },
//   {
//     title: "Total Vehicles",
//     description:
//       "Traffic congestion leads to frequent acceleration and braking, accelerating battery wear. Smooth driving reduces SOH loss.",
//     icon: <CarIcon />,
//   },
//   {
//     title: "Speed Average",
//     description:
//       "Consistently high speeds cause frequent deep discharges, lowering SOH. Maintaining stable speeds extends battery life.",
//     icon: <SpeedIcon />,
//   },
//   {
//     title: "Max Speed",
//     description:
//       "Excessive speed rapidly drains battery power, reducing overall longevity. Keeping speeds moderate enhances efficiency.",
//     icon: <SpeedIcon />,
//   },
//   {
//     title: "Radius",
//     description:
//       "Frequent sharp turns increase energy loss and tire friction, reducing efficiency. Smooth driving reduces wear.",
//     icon: <CarIcon />,
//   },
//   {
//     title: "Acceleration (m/s²)",
//     description:
//       "Rapid acceleration leads to high current draw, stressing battery cells. Gradual acceleration optimizes SOH.",
//     icon: <SpeedIcon />,
//   },
//   {
//     title: "Battery Capacity (Wh)",
//     description:
//       "Battery capacity declines with repeated charge cycles. Avoiding full discharges extends overall lifespan.",
//     icon: <BatteryIcon />,
//   },
//   {
//     title: "Longitude & Latitude",
//     description:
//       "Terrain and climate vary by location, affecting energy efficiency. Route optimization reduces unnecessary power use.",
//     icon: <GpsIcon />,
//   },
//   {
//     title: "Altitude",
//     description:
//       "Higher altitudes affect cooling efficiency and battery chemistry. Adaptive power management helps optimize usage.",
//     icon: <HeightIcon />,
//   },
//   {
//     title: "Slope (º)",
//     description:
//       "Climbing steep slopes increases energy demand, reducing SOH. Using regenerative braking conserves energy downhill.",
//     icon: <SlopeIcon />,
//   },
//   {
//     title: "Completed Distance (km)",
//     description:
//       "Long distances contribute to natural battery aging. Strategic charging patterns slow down degradation.",
//     icon: <CarIcon />,
//   },
//   {
//     title: "Remaining Range (km)",
//     description:
//       "Frequent full discharges lead to reduced capacity over time. Predictive range management improves SOH.",
//     icon: <BatteryIcon />,
//   },
// ];

// function DataCard({ title, description, icon, onClick }) {
//   return (
//     <motion.div
//       initial={{ y: 100, opacity: 0 }}
//       animate={{ y: 0, opacity: 1 }}
//       transition={{ duration: 0.6 }}
//     >
//       <Card
//         sx={{
//           width: 250,
//           height: 160,
//           display: "flex",
//           flexDirection: "column",
//           alignItems: "center",
//           justifyContent: "center",
//           textAlign: "center",
//           borderRadius: 3,
//           p: 2,
//           background: "linear-gradient(135deg, #ffffff, #f7f7f7)",
//           color: "#333",
//           transition: "transform 0.4s ease, box-shadow 0.4s ease",
//           cursor: "pointer",
//           "&:hover": {
//             transform: "scale(1.05)",
//             boxShadow: "0px 8px 20px rgba(0, 153, 255, 0.3)",
//           },
//         }}
//         onClick={onClick}
//       >
//         <CardContent sx={{ textAlign: "center" }}>
//           {icon}
//           <Typography
//             variant="h6"
//             sx={{ mt: 1, fontSize: "1rem", fontWeight: 600 }}
//           >
//             {title}
//           </Typography>
//         </CardContent>
//       </Card>
//     </motion.div>
//   );
// }

// export default function Home() {
//   const swiperRef = useRef(null);
//   const [selectedData, setSelectedData] = useState(null); // Track clicked card

//   return (
//     <Box sx={{ position: "relative", overflow: "hidden" }}>
//       {/* Animated Background */}
//       <motion.div
//         initial={{ scale: 1 }}
//         animate={{ scale: 1.1 }}
//         transition={{ duration: 10, repeat: Infinity, repeatType: "reverse" }}
//         style={{
//           position: "absolute",
//           top: 0,
//           left: 0,
//           width: "100%",
//           height: "40vh",
//           backgroundImage: `url(${HomeBackground})`,
//           backgroundSize: "cover",
//           backgroundPosition: "center",
//           zIndex: -1,
//           filter: "brightness(0.6)",
//         }}
//       />

//       {/* Overlay Text */}
//       <Box
//         sx={{
//           position: "absolute",
//           top: 0,
//           left: 0,
//           width: "100%",
//           height: "40vh",
//           background:
//             "linear-gradient(to bottom, rgba(0,0,0,0.6), rgba(0,0,0,0))",
//           display: "flex",
//           alignItems: "center",
//           justifyContent: "center",
//           textAlign: "center",
//         }}
//       >
//         <Typography variant="h3" sx={{ color: "#fff", fontWeight: 700 }}>
//           ⚡ EV Battery Optimization
//         </Typography>
//       </Box>

//       {/* Carousel */}
//       <Box
//         sx={{ padding: "20px", maxWidth: "90%", margin: "auto", mt: "200px" }}
//       >
//         <Swiper
//           slidesPerView={4}
//           spaceBetween={20}
//           navigation={true}
//           pagination={{ clickable: true }}
//           autoplay={{ delay: 3000, disableOnInteraction: false }}
//           modules={[Navigation, Pagination, Autoplay]}
//           onSwiper={(swiper) => (swiperRef.current = swiper)}
//           style={{ paddingBottom: "60px" }}
//         >
//           {dataPoints.map((item, index) => (
//             <SwiperSlide key={index}>
//               <DataCard {...item} onClick={() => setSelectedData(item)} />
//             </SwiperSlide>
//           ))}
//         </Swiper>
//       </Box>

//       {/* Modal for showing full content */}
//       <Modal
//         open={!!selectedData}
//         onClose={() => setSelectedData(null)}
//         sx={{
//           display: "flex",
//           alignItems: "center",
//           justifyContent: "center",
//         }}
//       >
//         <motion.div
//           initial={{ scale: 0.7, opacity: 0 }}
//           animate={{ scale: 1, opacity: 1 }}
//           transition={{ duration: 0.4 }}
//           style={{
//             background: "#fff",
//             padding: "20px",
//             borderRadius: "12px",
//             boxShadow: "0px 10px 30px rgba(0,0,0,0.2)",
//             maxWidth: "400px",
//             textAlign: "center",
//             position: "relative",
//           }}
//         >
//           <IconButton
//             onClick={() => setSelectedData(null)}
//             sx={{ position: "absolute", top: 10, right: 10 }}
//           >
//             <CloseIcon />
//           </IconButton>

//           {selectedData?.icon}
//           <Typography variant="h5" sx={{ mt: 1, fontWeight: "bold" }}>
//             {selectedData?.title}
//           </Typography>
//           <Typography variant="body1" sx={{ mt: 2, color: "#666" }}>
//             {selectedData?.description}
//           </Typography>
//         </motion.div>
//       </Modal>
//     </Box>
//   );
// }

// import React, { useState, useRef } from "react";
// import {
//   Typography,
//   Card,
//   CardContent,
//   Box,
//   Modal,
//   IconButton,
// } from "@mui/material";
// import { Swiper, SwiperSlide } from "swiper/react";
// import { Navigation, Pagination, Autoplay } from "swiper/modules";
// import { motion } from "framer-motion"; // Animation library
// import CloseIcon from "@mui/icons-material/Close";
// import ArrowBackIosIcon from "@mui/icons-material/ArrowBackIos";
// import ArrowForwardIosIcon from "@mui/icons-material/ArrowForwardIos";
// import "swiper/css";
// import "swiper/css/navigation";
// import "swiper/css/pagination";
// import BatteryChargingFullIcon from "@mui/icons-material/BatteryChargingFull";
// import SpeedIcon from "@mui/icons-material/Speed";
// import SyncIcon from "@mui/icons-material/Sync";
// import AcUnitIcon from "@mui/icons-material/AcUnit";
// import EvStationIcon from "@mui/icons-material/EvStation";
// import DeviceThermostatIcon from "@mui/icons-material/DeviceThermostat";
// import AirIcon from "@mui/icons-material/Air";
// import HeightIcon from "@mui/icons-material/Height";
// import GpsFixedIcon from "@mui/icons-material/GpsFixed";
// import HomeBackground from "../Assets/Background Images/HomeBackground.webp";

// // Data Points
// const dataPoints = [
//   {
//     title: "ELV Spy",
//     description: "Real-time battery monitoring",
//     icon: <EvStationIcon fontSize="large" />,
//   },
//   {
//     title: "Speed",
//     description: "Current vehicle speed",
//     icon: <SpeedIcon fontSize="large" />,
//   },
//   {
//     title: "SOC",
//     description: "Battery remaining (%)",
//     icon: <BatteryChargingFullIcon fontSize="large" />,
//   },
//   {
//     title: "Temperature",
//     description: "External temperature",
//     icon: <AcUnitIcon fontSize="large" />,
//   },
//   {
//     title: "Energy Regen",
//     description: "Recovered energy",
//     icon: <SyncIcon fontSize="large" />,
//   },
//   {
//     title: "Motor Temp",
//     description: "EV motor temperature",
//     icon: <DeviceThermostatIcon fontSize="large" />,
//   },
//   {
//     title: "Wind Speed",
//     description: "Affects aerodynamics",
//     icon: <AirIcon fontSize="large" />,
//   },
//   {
//     title: "Altitude",
//     description: "Height above sea level",
//     icon: <HeightIcon fontSize="large" />,
//   },
//   {
//     title: "Longitude",
//     description: "Geolocation data",
//     icon: <GpsFixedIcon fontSize="large" />,
//   },
// ];

// function DataCard({ title, description, icon, onClick }) {
//   return (
//     <motion.div
//       initial={{ y: 100, opacity: 0 }}
//       animate={{ y: 0, opacity: 1 }}
//       transition={{ duration: 0.6 }}
//     >
//       <Card
//         sx={{
//           width: 250,
//           height: 160,
//           display: "flex",
//           flexDirection: "column",
//           alignItems: "center",
//           justifyContent: "center",
//           textAlign: "center",
//           borderRadius: 3,
//           p: 2,
//           background: "linear-gradient(135deg, #ffffff, #f7f7f7)",
//           color: "#333",
//           transition: "transform 0.4s ease, box-shadow 0.4s ease",
//           cursor: "pointer",
//           "&:hover": {
//             transform: "scale(1.05)",
//             boxShadow: "0px 8px 20px rgba(0, 153, 255, 0.3)",
//           },
//         }}
//         onClick={onClick}
//       >
//         <CardContent sx={{ textAlign: "center" }}>
//           {icon}
//           <Typography
//             variant="h6"
//             sx={{ mt: 1, fontSize: "1rem", fontWeight: 600 }}
//           >
//             {title}
//           </Typography>
//         </CardContent>
//       </Card>
//     </motion.div>
//   );
// }

// export default function Home() {
//   const swiperRef = useRef(null);
//   const [selectedData, setSelectedData] = useState(null);

//   return (
//     <Box sx={{ position: "relative", overflow: "hidden" }}>
//       {/* Animated Background */}
//       <motion.div
//         initial={{ scale: 1 }}
//         animate={{ scale: 1.1 }}
//         transition={{ duration: 10, repeat: Infinity, repeatType: "reverse" }}
//         style={{
//           position: "absolute",
//           top: 0,
//           left: 0,
//           width: "100%",
//           height: "40vh",
//           backgroundImage: `url(${HomeBackground})`,
//           backgroundSize: "cover",
//           backgroundPosition: "center",
//           zIndex: -1,
//           filter: "brightness(0.6)",
//         }}
//       />

//       {/* Overlay Text */}
//       <Box
//         sx={{
//           position: "absolute",
//           top: 0,
//           left: 0,
//           width: "100%",
//           height: "40vh",
//           background:
//             "linear-gradient(to bottom, rgba(0,0,0,0.6), rgba(0,0,0,0))",
//           display: "flex",
//           alignItems: "center",
//           justifyContent: "center",
//           textAlign: "center",
//         }}
//       >
//         <Typography variant="h3" sx={{ color: "#fff", fontWeight: 700 }}>
//           ⚡ EV Battery Optimization
//         </Typography>
//       </Box>

//       {/* Carousel Section */}
//       <Box
//         sx={{
//           padding: "20px",
//           maxWidth: "90%",
//           margin: "auto",
//           mt: "200px",
//           position: "relative",
//         }}
//       >
//         {/* Left Navigation Button */}
//         <IconButton
//           onClick={() => swiperRef.current?.slidePrev()}
//           sx={{
//             position: "absolute",
//             left: "-50px",
//             top: "50%",
//             transform: "translateY(-50%)",
//             background: "#fff",
//             boxShadow: "0px 4px 10px rgba(0, 0, 0, 0.2)",
//             zIndex: 10,
//           }}
//         >
//           <ArrowBackIosIcon />
//         </IconButton>

//         {/* Swiper Carousel */}
//         <Swiper
//           slidesPerView={4}
//           spaceBetween={20}
//           pagination={{ clickable: true }}
//           autoplay={{ delay: 3000, disableOnInteraction: false }}
//           modules={[Navigation, Pagination, Autoplay]}
//           onSwiper={(swiper) => (swiperRef.current = swiper)}
//           style={{ paddingBottom: "60px" }}
//         >
//           {dataPoints.map((item, index) => (
//             <SwiperSlide key={index}>
//               <DataCard {...item} onClick={() => setSelectedData(item)} />
//             </SwiperSlide>
//           ))}
//         </Swiper>

//         {/* Right Navigation Button */}
//         <IconButton
//           onClick={() => swiperRef.current?.slideNext()}
//           sx={{
//             position: "absolute",
//             right: "-50px",
//             top: "50%",
//             transform: "translateY(-50%)",
//             background: "#fff",
//             boxShadow: "0px 4px 10px rgba(0, 0, 0, 0.2)",
//             zIndex: 10,
//           }}
//         >
//           <ArrowForwardIosIcon />
//         </IconButton>
//       </Box>
//     </Box>
//   );
// }

import React, { useState, useRef } from "react";
import {
  Typography,
  Card,
  CardContent,
  Box,
  Modal,
  IconButton,
} from "@mui/material";
import { Swiper, SwiperSlide } from "swiper/react";
import { Navigation, Pagination, Autoplay } from "swiper/modules";
import { motion } from "framer-motion"; // Animation library
import CloseIcon from "@mui/icons-material/Close";
import "swiper/css";
import "swiper/css/navigation";
import "swiper/css/pagination";
import { Collapse } from "@mui/material";
import HomeBackground from "../Assets/Background Images/HomeBackground.webp";
import {
  EvStation as EvStationIcon,
  Speed as SpeedIcon,
  BatteryChargingFull as BatteryIcon,
  AcUnit as AcUnitIcon,
  Sync as SyncIcon,
  DeviceThermostat as ThermostatIcon,
  Air as AirIcon,
  Height as HeightIcon,
  GpsFixed as GpsIcon,
  DirectionsCar as CarIcon,
  FlashOn as FlashIcon,
  Speed as RpmIcon,
  Storage as DataIcon,
  Timeline as GraphIcon,
  LocationOn as LocationIcon,
  CompareArrows as SlopeIcon,
  RotateRight as TorqueIcon,
} from "@mui/icons-material";

// Data Points
const dataPoints = [
  {
    title: "ELV Spy",
    description:
      "Monitors battery voltage, current, and temperature in real-time. Early detection of fluctuations helps prevent rapid degradation.",
    icon: <EvStationIcon />,
  },
  {
    title: "Speed",
    description:
      "High speeds cause excessive battery discharge cycles, accelerating capacity loss. Maintaining moderate speeds improves longevity.",
    icon: <SpeedIcon />,
  },
  {
    title: "SOC (State of Charge)",
    description:
      "Extreme SOC levels (0% or 100%) stress battery cells, reducing lifespan. Keeping SOC between 20-80% optimizes health.",
    icon: <BatteryIcon />,
  },
  {
    title: "Ambient Temperature",
    description:
      "High temperatures accelerate chemical degradation, while cold reduces charge efficiency. Thermal management stabilizes SOH.",
    icon: <AcUnitIcon />,
  },
  {
    title: "Regenerated Energy (Wh)",
    description:
      "Efficient regenerative braking reduces deep discharge cycles, improving overall battery lifespan.",
    icon: <SyncIcon />,
  },
  {
    title: "Motor Power (W)",
    description:
      "High power output increases heat and battery stress. Smooth acceleration reduces strain and extends lifespan.",
    icon: <FlashIcon />,
  },
  {
    title: "Aux Power (100W)",
    description:
      "Excessive auxiliary power drains the battery, reducing available energy for driving. Optimizing power consumption preserves range.",
    icon: <DataIcon />,
  },
  {
    title: "Motor Temperature",
    description:
      "Overheating can cause thermal runaway, permanently damaging the battery. Proper cooling systems prevent overheating.",
    icon: <ThermostatIcon />,
  },
  {
    title: "Torque (Nm)",
    description:
      "High torque demand leads to rapid battery discharge, affecting SOH. Gentle acceleration minimizes strain on cells.",
    icon: <TorqueIcon />,
  },
  {
    title: "RPM",
    description:
      "High RPM increases heat and energy loss, leading to inefficiency. Optimizing gear ratios and driving habits improves SOH.",
    icon: <RpmIcon />,
  },
  {
    title: "Battery Capacity",
    description:
      "Frequent deep discharges reduce battery capacity over time. Partial charging strategies slow down SOH decline.",
    icon: <BatteryIcon />,
  },
  {
    title: "Reference Consumption",
    description:
      "High energy consumption drains the battery faster, reducing cycle life. Efficient driving techniques enhance SOH.",
    icon: <GraphIcon />,
  },
  {
    title: "Wind Speed (mph & kph)",
    description:
      "Strong winds increase resistance, requiring more power and shortening battery lifespan. Adjusting speed reduces drag effects.",
    icon: <AirIcon />,
  },
  {
    title: "Wind Degree",
    description:
      "Crosswinds increase energy usage, leading to faster discharge. Predictive driving can minimize energy waste.",
    icon: <AirIcon />,
  },
  {
    title: "Frontal Wind",
    description:
      "Headwinds force the motor to work harder, increasing energy demand. Lower speeds reduce wind resistance and save energy.",
    icon: <AirIcon />,
  },
  {
    title: "Vehicle Angle",
    description:
      "Steep inclines demand more power, depleting battery faster. Regenerative braking helps recover energy downhill.",
    icon: <CarIcon />,
  },
  {
    title: "Total Vehicles",
    description:
      "Traffic congestion leads to frequent acceleration and braking, accelerating battery wear. Smooth driving reduces SOH loss.",
    icon: <CarIcon />,
  },
  {
    title: "Speed Average",
    description:
      "Consistently high speeds cause frequent deep discharges, lowering SOH. Maintaining stable speeds extends battery life.",
    icon: <SpeedIcon />,
  },
  {
    title: "Max Speed",
    description:
      "Excessive speed rapidly drains battery power, reducing overall longevity. Keeping speeds moderate enhances efficiency.",
    icon: <SpeedIcon />,
  },
  {
    title: "Radius",
    description:
      "Frequent sharp turns increase energy loss and tire friction, reducing efficiency. Smooth driving reduces wear.",
    icon: <CarIcon />,
  },
  {
    title: "Acceleration (m/s²)",
    description:
      "Rapid acceleration leads to high current draw, stressing battery cells. Gradual acceleration optimizes SOH.",
    icon: <SpeedIcon />,
  },
  {
    title: "Battery Capacity (Wh)",
    description:
      "Battery capacity declines with repeated charge cycles. Avoiding full discharges extends overall lifespan.",
    icon: <BatteryIcon />,
  },
  {
    title: "Longitude & Latitude",
    description:
      "Terrain and climate vary by location, affecting energy efficiency. Route optimization reduces unnecessary power use.",
    icon: <GpsIcon />,
  },
  {
    title: "Altitude",
    description:
      "Higher altitudes affect cooling efficiency and battery chemistry. Adaptive power management helps optimize usage.",
    icon: <HeightIcon />,
  },
  {
    title: "Slope (º)",
    description:
      "Climbing steep slopes increases energy demand, reducing SOH. Using regenerative braking conserves energy downhill.",
    icon: <SlopeIcon />,
  },
  {
    title: "Completed Distance (km)",
    description:
      "Long distances contribute to natural battery aging. Strategic charging patterns slow down degradation.",
    icon: <CarIcon />,
  },
  {
    title: "Remaining Range (km)",
    description:
      "Frequent full discharges lead to reduced capacity over time. Predictive range management improves SOH.",
    icon: <BatteryIcon />,
  },
];

function DataCard({ title, description, icon, onClick, open }) {
  return (
    <motion.div
      initial={{ y: 100, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.6 }}
    >
      <Card
        sx={{
          width: 250,
          height: open ? "auto" : 160,
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          justifyContent: "center",
          textAlign: "center",
          borderRadius: 3,
          p: 2,
          background: "rgba(255, 255, 255, 0.1)", // Glassmorphism background
          backdropFilter: "blur(10px)", // Blurring background
          color: "#333",
          transition: "transform 0.4s ease, box-shadow 0.4s ease",
          cursor: "pointer",
          boxShadow: open
            ? "0px 4px 20px rgba(0, 153, 255, 0.3)"
            : "0px 8px 20px rgba(0, 153, 255, 0.3)",
          "&:hover": {
            transform: "scale(1.05)",
            boxShadow: "0px 8px 20px rgba(0, 153, 255, 0.3)",
          },
        }}
        onClick={onClick}
      >
        <CardContent sx={{ textAlign: "center" }}>
          {icon}
          <Typography
            variant="h6"
            sx={{ mt: 1, fontSize: "1rem", fontWeight: 600 }}
          >
            {title}
          </Typography>
        </CardContent>

        {/* Expandable content */}
        <Collapse in={open} timeout="auto" unmountOnExit>
          <Typography variant="body1" sx={{ mt: 2, color: "#666" }}>
            {description}
          </Typography>
        </Collapse>
      </Card>
    </motion.div>
  );
}

export default function Home() {
  const swiperRef = useRef(null);
  const [selectedData, setSelectedData] = useState(null); // Track clicked card
  const [expandedCard, setExpandedCard] = useState(null); // Track which card is expanded

  const handleCardClick = (card) => {
    setExpandedCard(expandedCard === card ? null : card); // Toggle expand/collapse
    setSelectedData(card); // Set data to show in the expanded state
  };

  return (
    <Box sx={{ position: "relative", overflow: "hidden" }}>
      {/* Animated Background */}
      <motion.div
        initial={{ scale: 1 }}
        animate={{ scale: 1.1 }}
        transition={{ duration: 10, repeat: Infinity, repeatType: "reverse" }}
        style={{
          position: "absolute",
          top: 0,
          left: 0,
          width: "100%",
          height: "40vh",
          backgroundImage: `url(${HomeBackground})`,
          backgroundSize: "cover",
          backgroundPosition: "center",
          zIndex: -1,
          filter: "brightness(0.6)",
        }}
      />

      {/* Overlay Text */}
      <Box
        sx={{
          position: "absolute",
          top: 0,
          left: 0,
          width: "100%",
          height: "40vh",
          background:
            "linear-gradient(to bottom, rgba(0,0,0,0.6), rgba(0,0,0,0))",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          textAlign: "center",
        }}
      >
        <Typography variant="h3" sx={{ color: "#fff", fontWeight: 700 }}>
          ⚡ EV Battery Optimization
        </Typography>
      </Box>

      {/* Carousel */}
      <Box
        sx={{ padding: "20px", maxWidth: "90%", margin: "auto", mt: "200px" }}
      >
        <Swiper
          slidesPerView={4}
          spaceBetween={20}
          navigation={true}
          pagination={{ clickable: true }}
          autoplay={{ delay: 3000, disableOnInteraction: false }}
          modules={[Navigation, Pagination, Autoplay]}
          onSwiper={(swiper) => (swiperRef.current = swiper)}
          style={{ paddingBottom: "60px" }}
        >
          {dataPoints.map((item, index) => (
            <SwiperSlide key={index}>
              <DataCard
                {...item}
                onClick={() => handleCardClick(item)}
                open={expandedCard === item}
              />
            </SwiperSlide>
          ))}
        </Swiper>
      </Box>
    </Box>
  );
}
